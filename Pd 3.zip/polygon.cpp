#include <iostream>
using namespace std;
main()
{
int numberofsides;
int sumofinternalangles;
cout<< " enter numberofsides " <<endl;
cin>> numberofsides ;
sumofinternalangles = (numberofsides - 2) * 180 ; 
cout<< "sumofinternalangles=" <<sumofinternalangles <<endl; 
}
