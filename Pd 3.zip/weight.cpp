#include <iostream>
using namespace std;
main()
{
string name;
int weightinKg;
int numberofdays;
cout<< " enter your name " <<endl;
cin>> name ;
cout<< " enter weightinKg " <<endl;
cin>> weightinKg;
numberofdays = 15 * weightinKg ;
cout<< "numberofdays="<<numberofdays <<endl;
}