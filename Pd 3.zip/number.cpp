#include <iostream>
using namespace std;
main()
{
int num1 , num2 , sum;
int num3 , num4 , num5 ;
cout<< " enter the num1 " <<endl;
cin>> num1;
cout<< "enter the num2 " <<endl;
cin>> num2;
cout<< "enter the num3 " <<endl;
cin>> num3;
cout<< "enter the num4 " <<endl;
cin>> num4;
cout<< " enter the num5 " <<endl;
cin>>num5;
sum = num1 + num2 + num3 + num4 + num5;
cout<< "sum= " <<sum  <<endl;
}